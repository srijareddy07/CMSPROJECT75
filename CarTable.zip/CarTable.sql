use Training_19Sep19_Pune
go

create table [46008575].Car
(
Id int identity(1,1) primary key,
Model Varchar(30) unique,
ManufacturerId Varchar(30) not null,
TypeId Int not null,
Engine Varchar(30),
BHP Int not null,
TransmissionId Int not null,
Mileage Int Not Null,
Seat Int Not Null,
AirBagDetails varchar(20) Not Null,
BootSpace Varchar(30) not null,
Price decimal not null
);
drop table [46008575].CarTransmissionType


create table [46008575].Manufacturer
(
Id int identity(1,1) primary key,
ManufacturerName varchar(30) unique,
ContactPerson varchar(20) unique,
RegisteredOffice varchar(30) not null
);

create table [46008575].CarType
(
Id int identity(1,1) primary key,
CarType varchar(30) unique
);

create table [46008575].CarTransmissionType
(
Id int identity(1,1) primary key, 
 Name varchar(20) unique
);


