﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMSBAL;
using CMSEntities;
using CMSExceptions;

namespace CMS
{
    /// <summary>
    /// Interaction logic for SearchCarByName.xaml
    /// </summary>
    public partial class SearchCar : Window
    {
        public SearchCar()
        {
            InitializeComponent();
        }

        private void BtnSearchCar_Click(object sender, RoutedEventArgs e)
        {
            searchCar();
        }

        private void Btnreturn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objmain = new MainWindow();
            objmain.Show();
            this.Close();
        }
        private void searchCar()
        {

            string ManufacturerName;
            string Type;
            CarEntities objcar = null;
            try
            {
                if (cmbManufacturerName.Text != "" && cmbCarType.Text != "")
                {
                    ManufacturerName = cmbManufacturerName.Text;
                    Type = cmbCarType.Text;
                    objcar = CarBAL.SearchCarByNameBAL(ManufacturerName);
                    objcar = CarBAL.SearchCarByModelBAL(Type);
                    if (objcar != null)
                    {
                        cmbManufacturerName.Text = objcar.ManufacturerName;
                        txtModel.Text = objcar.Model;
                        cmbCarType.Text = objcar.Type;
                        txtEngine.Text = objcar.Engine;
                        txtBHP.Text = objcar.BHP.ToString();
                        cmbTransmissionType.Text = objcar.Transmission;
                        txtMileage.Text = objcar.Mileage.ToString();
                        txtSeats.Text = objcar.Seats.ToString();
                        txtAirbags.Text = objcar.AirBagDetails;
                        txtBootSpace.Text = objcar.BootSpace.ToString();
                        txtPrice.Text = objcar.Price.ToString();
                    }
                    else
                        MessageBox.Show("Car not found");
                }
                else
                {
                    MessageBox.Show("Please Enter ManufacturerName and Type to Search");
                }
            }

            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
