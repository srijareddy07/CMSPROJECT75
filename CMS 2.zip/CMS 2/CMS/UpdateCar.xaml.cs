﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMSBAL;
using CMSEntities;
using CMSExceptions;

namespace CMS
{
    /// <summary>
    /// Interaction logic for UpdateCar.xaml
    /// </summary>
    public partial class UpdateCar : Window
    {
        public UpdateCar()
        {
            InitializeComponent();
        }



        private void SearchCar_Click(object sender, RoutedEventArgs e)
        {
            Searchcar();
        }

        private void Updatecar_Click_1(object sender, RoutedEventArgs e)
        {
            Updatecardetails();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
        private void Updatecardetails()
        {
            bool CarUpdated;
            try
            {

                CarEntities objcar = new CarEntities();

                objcar.ManufacturerName = cmbManufacturerName.Text;
                objcar.Model = txtModel.Text;
                objcar.Type = cmbType.Text;
                objcar.Engine = txtEngine.Text;
                objcar.BHP = Convert.ToInt32(txtBHP.Text);
                objcar.Transmission = cmbTransmissionId.Text;
                objcar.Mileage = Convert.ToInt32(txtMileage.Text);
                objcar.Seats = Convert.ToInt32(txtSeats.Text);
                objcar.AirBagDetails = txtAirbag.Text;
                objcar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                objcar.Price = Convert.ToDouble(txtPrice.Text);

                CarUpdated = CarBAL.UpdateCarBAL(objcar);


                if (CarUpdated)
                {
                    MessageBox.Show("Car details added successfully.");
                }
                else
                {
                    MessageBox.Show("car details couldn't be added.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Searchcar()
        {

            string ManufacturerName;
            string Type;
            CarEntities objcar = null;
            try
            {
                if (cmbManufacturerName.Text != "" && cmbType.Text != "")
                {
                    ManufacturerName = cmbManufacturerName.Text;
                    Type = cmbType.Text;
                    objcar = CarBAL.SearchCarByNameBAL(ManufacturerName);
                    objcar = CarBAL.SearchCarByModelBAL(Type);
                    if (objcar != null)
                    {
                        cmbManufacturerName.Text = objcar.ManufacturerName;
                        txtModel.Text = objcar.Model;
                        cmbType.Text = objcar.Type;
                        txtEngine.Text = objcar.Engine;
                        txtBHP.Text = objcar.BHP.ToString();
                        cmbTransmissionId.Text = objcar.Transmission;
                        txtMileage.Text = objcar.Mileage.ToString();
                        txtSeats.Text = objcar.Seats.ToString();
                        txtAirbag.Text = objcar.AirBagDetails;
                        txtBootSpace.Text = objcar.BootSpace.ToString();
                        txtPrice.Text = objcar.Price.ToString();
                    }
                    else
                        MessageBox.Show("Car not found");
                }
                else
                {
                    MessageBox.Show("Please Enter ManufacturerName and Type to Search");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
