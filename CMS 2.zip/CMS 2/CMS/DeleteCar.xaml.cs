﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMSBAL;
using CMSEntities;
using CMSExceptions;

namespace CMS
{
    /// <summary>
    /// Interaction logic for DeleteCar.xaml
    /// </summary>
    public partial class DeleteCar : Window
    {
        public DeleteCar()
        {
            InitializeComponent();
        }

        
        private void Return_Click(object sender, RoutedEventArgs e)
        {
            Admin admin = new Admin();
            admin.Show();
            this.Close();
        }

        private void Deletecar_Click_1(object sender, RoutedEventArgs e)
        {
            deleteCar();
        }

        private void deleteCar()
        {
            try
            {
                string Model;
                //
                bool CarDeleted;
                //
                Model = txtModel.Text;
                //
                CarDeleted = CarBAL.DeleteCarBAL(Model);
                if (CarDeleted == true)
                {
                    MessageBox.Show("car details deleted successfully.");
                }
                else
                {
                    MessageBox.Show("details of car couldn't be deleted.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
