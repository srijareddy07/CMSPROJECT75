﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMSBAL;
using CMSEntities;
using CMSExceptions;

namespace CMS
{
    /// <summary>
    /// Interaction logic for AddCar.xaml
    /// </summary>
    public partial class AddCar : Window
    {
        public AddCar()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void Return_Click(object sender, RoutedEventArgs e)
        {
            Admin admin = new Admin();
            admin.Show();
            this.Close();
        }

        private void Addcar_Click_1(object sender, RoutedEventArgs e)
        {
            AddCardetails();
        }
        public void AddCardetails()
        {

            bool CarAdded;
            try
            {

                //
                CarEntities objcar = new CarEntities();


                objcar.ManufacturerName = cmbManufacturerName.Text;
                objcar.Model = txtModel.Text;
                objcar.Type = cmbType.Text;
                objcar.Engine = txtEngine.Text;
                objcar.BHP = Convert.ToInt32(txtBHP.Text);
                objcar.Transmission = cmbTransmissionId.Text;
                objcar.Mileage = Convert.ToInt32(txtMileage.Text);
                objcar.Seats = Convert.ToInt32(txtSeats.Text);
                objcar.AirBagDetails = txtAirbag.Text;
                objcar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                objcar.Price = Convert.ToDouble(txtPrice.Text);

                CarAdded = CarBAL.AddCarBAL(objcar);


                if (CarAdded)
                {
                    MessageBox.Show("car details added successfully.");
                }
                else
                {
                    MessageBox.Show("details of car couldn't be added.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
