﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CMS
{
    /// <summary>
    /// Interaction logic for Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void AddCar_Click(object sender, RoutedEventArgs e)
        {
            AddCar objAddcar = new AddCar();
            objAddcar.Show();
            this.Close();

        }

        private void UpdateCar_Click(object sender, RoutedEventArgs e)
        {
            UpdateCar objUpdatecar = new UpdateCar();
            objUpdatecar.Show();
            this.Close();

        }

        private void DeleteCar_Click(object sender, RoutedEventArgs e)
        {
            DeleteCar objDeleteCar = new DeleteCar();
            objDeleteCar.Show();
            this.Close();
        }

        private void SearchCar_Click(object sender, RoutedEventArgs e)
        {
            SearchCar objSearchCar = new SearchCar();
            objSearchCar.Show();
            this.Close();
        }

        private void ListOfCars_Click(object sender, RoutedEventArgs e)
        {
            GetCarList carlist = new GetCarList();
            carlist.Show();
            this.Close();
        }
        private void Return_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objmain = new MainWindow();
            objmain.Show();
            this.Close();
           
        }
    }
}
