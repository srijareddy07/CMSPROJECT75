﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CMS
{
    /// <summary>
    /// Interaction logic for Customer.xaml
    /// </summary>
    public partial class Customer : Window
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void SearchCar_Click(object sender, RoutedEventArgs e)
        {
            SearchCar objsearchcar = new SearchCar();
            objsearchcar.Show();
            this.Close();
        }

        private void ListOfCars_Click(object sender, RoutedEventArgs e)
        {
            GetCarList carlist = new GetCarList();
            carlist.Show();
            this.Close();
        }

        private void Return_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objmain = new MainWindow();
            objmain.Show();
            this.Close();
        }
    }
}
 