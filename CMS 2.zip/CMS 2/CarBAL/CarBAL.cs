﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CMSDAL;
using CMSEntities;
using CMSExceptions;

namespace CMSBAL
{
    public class CarBAL
    {
        public static bool IsValid(CarEntities Car)
        {
            bool valid = true;
            StringBuilder errorMessage = new StringBuilder();
            try
            {
                if (Car.ManufacturerName == string.Empty || Car.Model == string.Empty || Car.Type == string.Empty || Car.Engine == string.Empty || Car.BHP.ToString() == string.Empty || Car.Transmission == string.Empty || Car.Mileage <= 0 || Car.Seats <= 0 || Car.AirBagDetails == string.Empty || Car.BootSpace <= 0 ||  Car.Price <= 0)
                {

                    valid = false;
                    errorMessage.AppendLine("All fields are mandatory");
                }
                if (Car.Type != "Hatchback" && Car.Type != "SUV" && Car.Type != "Sedan")
                {
                    valid = false;
                    errorMessage.AppendLine("Type name should be Hatchback or Sedan or SUV");
                }
                if (!(Regex.IsMatch(Car.Engine, @"^\d\.\dL$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Engine name should have 4 characters with 1st and 3rd character number ,2nd '.' and last 'L'");
                }
                if (!(Regex.IsMatch(Car.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("BHP should be a number");
                }
                if (Car.Transmission != "Manual" && Car.Transmission != "Automatic")
                {
                    valid = false;
                    errorMessage.AppendLine("Transmission type Should be either Manual or Automatic");
                }
                if (!(Regex.IsMatch(Car.Mileage.ToString(), @"^[0-9]{2}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Mileage should be a number");
                }
                if (!(Regex.IsMatch(Car.Seats.ToString(), @"^[0-9]{1}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("seats should be a number");
                }
                if (!(Regex.IsMatch(Car.AirBagDetails, @"^[A-Za-z]+$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Airbags details should be a string");
                }
                if (!(Regex.IsMatch(Car.BootSpace.ToString(), @"^[0-9]{1,3}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Bootspace should be a number with 3 digits");
                }
                
                if (!(Regex.IsMatch(Car.Price.ToString(), @"^[0-9]+$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Price should be a number");
                }
                if (!valid)
                {
                    throw new CarExceptions(errorMessage.ToString());
                }
            }
            catch (CarExceptions objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return valid;

        }
        public static CarDAL objCarDAL = new CarDAL();
        public static bool AddCarBAL(CarEntities car)
        {
            bool CarAdded;
            try
            {
                CarAdded = objCarDAL.AddCarDAL(car);
            }
            catch (CarExceptions objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return CarAdded;
        }
        public static bool UpdateCarBAL(CarEntities car)
        {
            bool CarUpdated;
            try
            {
                CarUpdated = objCarDAL.UpdateCarDAL(car);
            }
            catch (CarExceptions objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return CarUpdated;
        }
        public static bool DeleteCarBAL(string Model)
        {
            bool CarDeleted;
            try
            {
                CarDeleted = objCarDAL.DeleteCarDAL(Model);
            }
            catch (CarExceptions objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return CarDeleted;
        }
        public static CarEntities SearchCarByNameBAL(string Name)
        {
            CarEntities objCar = null;
            try
            {
                objCar = objCarDAL.SearchCarByNameDAL(Name);
            }
            catch (CarExceptions objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objCar;
        }
        public static CarEntities SearchCarByModelBAL(string model)
        {

            CarEntities objCar = null;
            try
            {
                objCar = objCarDAL.SearchCarByModelDAL(model);
            }
            catch (CarExceptions objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objCar;
        }
        public static List<CarEntities> GetListBAL(string name, string type)
        {
            List<CarEntities> objCars = null;
            try
            {
                objCars = objCarDAL.ListAllCars(name, type);
            }
            catch (CarExceptions objCarEx)
            {
                throw objCarEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objCars;
        }
    }
}


